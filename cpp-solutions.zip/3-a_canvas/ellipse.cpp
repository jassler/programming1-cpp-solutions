#include "ellipse.h"

Ellipse::Ellipse(int _width, int _height, char _fill)
	: Shape(_width, _height, _fill)
{
}
