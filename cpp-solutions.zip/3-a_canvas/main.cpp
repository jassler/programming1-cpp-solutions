#include "rectangle.h"
#include "ellipse.h"

int main()
{
	Shape* p = new Ellipse(30, 10, '+');
	p->draw();
	delete p;
}
