#include <iostream>
#include <string>
#include "rectangle.h"

Rectangle::Rectangle(int _width, int _height, char _border, char _fill)
	: Shape(_width, _height, _fill), border(_border)
{
}

void Rectangle::draw()
{
	std::string top_str = std::string(get_width(), get_border());
	std::string body_str;

	// if width is 0, body_str is empty
	// special case for width 1
	// otherwise border to the left and right, width-2 chars in the middle
	if (get_width() == 1)
	{
		body_str += get_border();
	}
	else if(get_width() > 1)
	{
		body_str += get_border() + std::string(get_width() - 2, get_fill()) + get_border();
	}


	// top
	std::cout << top_str << '\n';

	// body
	for (int i = 0; i < get_height() - 2; i++)
	{
		std::cout << body_str << '\n';
	}

	// bottom
	std::cout << top_str << '\n';
}

char Rectangle::get_border()
{
	return border;
}
