#pragma once
#define _USE_MATH_DEFINES
#include <iostream>
#include <vector>
#include <cmath>
#include "shape.h"

class Ellipse :
	public Shape
{
public:
	Ellipse(int _width, int _height, char _fill = '#');

	void draw() {
		std::vector<std::string> lines(get_height(), std::string(get_width(), ' '));

		int center_x = get_width() / 2;
		int center_y = get_height() / 2;

		for (int i = 0; i < get_width(); i++)
		{
			int dx = i - get_width() / 2;
			int x = center_x + dx;

			int h = (int)std::round(get_height() * std::sqrt(
				get_width() * get_width() / 4.0 - dx * dx) / get_width());

			for (int dy = 1; dy <= h; dy++) {
				lines[center_y + dy][x] = get_fill();
				lines[center_y - dy][x] = get_fill();
			}

			if (h >= 0) {
				lines[center_y][x] = get_fill();
			}
		}

		for (auto& line : lines)
			std::cout << line << '\n';
	} // void draw

	double area() {
		return M_PI * get_width() * get_height() / 4;
	}
};


