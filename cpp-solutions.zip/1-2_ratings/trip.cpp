#include "trip.h"

Trip::Trip(std::string _dest, unsigned int _duration, unsigned int _price)
: destination(_dest), duration(_duration), price(_price)
{
    // everything already initialized, nothing to do here
}